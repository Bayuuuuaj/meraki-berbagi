import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { storage } from "./storage";
import type { User } from "@shared/schema";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { fromError } from "zod-validation-error";

// Add user to session type
declare global {
  namespace Express {
    interface User {
      id: string;
      email: string;
      name: string;
      role: string;
      isActive: number;
    }
  }
}

// Configure Passport Local Strategy
passport.use(
  new LocalStrategy(
    {
      usernameField: "email",
      passwordField: "password",
    },
    async (email, password, done) => {
      try {
        const user = await storage.getUserByEmail(email);
        if (!user) {
          return done(null, false, { message: "Email atau password salah" });
        }

        if (user.isActive === 0) {
          return done(null, false, { message: "Akun tidak aktif" });
        }

        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
          return done(null, false, { message: "Email atau password salah" });
        }

        // Don't send password to client
        const { password: _, ...userWithoutPassword } = user;
        return done(null, userWithoutPassword as Express.User);
      } catch (error) {
        return done(error);
      }
    }
  )
);

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: string, done) => {
  try {
    const user = await storage.getUser(id);
    if (!user) {
      return done(null, false);
    }
    const { password: _, ...userWithoutPassword } = user;
    done(null, userWithoutPassword as Express.User);
  } catch (error) {
    done(error);
  }
});

// Middleware to check if user is authenticated
function isAuthenticated(req: any, res: any, next: any) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Middleware to check if user is admin
function isAdmin(req: any, res: any, next: any) {
  if (req.isAuthenticated() && req.user.role === "admin") {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin access required" });
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "meraki-berbagi-secret-key-change-in-production",
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
        secure: process.env.NODE_ENV === "production",
      },
    })
  );

  app.use(passport.initialize());
  app.use(passport.session());

  // ===== AUTH ROUTES =====
  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: Express.User, info: any) => {
      if (err) {
        return res.status(500).json({ message: "Server error" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Login gagal" });
      }
      req.logIn(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Server error" });
        }
        return res.json({ user });
      });
    })(req, res, next);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.json({ message: "Logout berhasil" });
    });
  });

  app.get("/api/auth/me", isAuthenticated, (req, res) => {
    res.json({ user: req.user });
  });

  // ===== USER MANAGEMENT ROUTES (Admin only) =====
  app.get("/api/users", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Remove passwords from response
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/users", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const schema = z.object({
        email: z.string().email(),
        password: z.string().min(6),
        name: z.string().min(1),
        role: z.enum(["admin", "anggota"]),
        isActive: z.number().optional(),
      });

      const data = schema.parse(req.body);
      
      // Check if email already exists
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email sudah terdaftar" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(data.password, 10);
      
      const user = await storage.createUser({
        ...data,
        password: hashedPassword,
        isActive: data.isActive ?? 1,
      });

      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromError(error).toString() });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.patch("/api/users/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const schema = z.object({
        email: z.string().email().optional(),
        name: z.string().min(1).optional(),
        role: z.enum(["admin", "anggota"]).optional(),
        isActive: z.number().optional(),
      });

      const data = schema.parse(req.body);
      
      // Check if target user is super admin
      const targetUser = await storage.getUser(id);
      if (targetUser?.isSuperAdmin === 1) {
        return res.status(403).json({ message: "Tidak bisa mengubah super admin" });
      }

      const user = await storage.updateUser(id, data);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromError(error).toString() });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete("/api/users/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      // Check if target user is super admin
      const targetUser = await storage.getUser(id);
      if (targetUser?.isSuperAdmin === 1) {
        return res.status(403).json({ message: "Tidak bisa menghapus super admin" });
      }

      const deleted = await storage.deleteUser(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ message: "User deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // ===== ATTENDANCE ROUTES =====
  app.get("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const attendanceRecords = await storage.getAllAttendance();
      
      // Members only see their own data, admin sees all
      const filtered = req.user!.role === "admin" 
        ? attendanceRecords 
        : attendanceRecords.filter(a => a.userId === req.user!.id);
      
      // Join with user data
      const attendanceWithUsers = await Promise.all(
        filtered.map(async (record) => {
          const user = await storage.getUser(record.userId);
          return {
            ...record,
            userName: user?.name || "Unknown",
            userEmail: user?.email || "",
          };
        })
      );
      
      res.json(attendanceWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance" });
    }
  });

  app.post("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const schema = z.object({
        userId: z.string().optional(),
        date: z.string(),
        status: z.enum(["hadir", "izin", "sakit", "alpha"]),
        notes: z.string().optional(),
        checkInTime: z.string().optional(),
      });

      const data = schema.parse(req.body);
      
      // Members can only create attendance for themselves, admin can create for anyone
      const userId = data.userId || req.user!.id;
      if (req.user!.role !== "admin" && userId !== req.user!.id) {
        return res.status(403).json({ message: "Cannot create attendance for other users" });
      }

      const attendance = await storage.createAttendance({
        ...data,
        userId,
      });
      res.status(201).json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromError(error).toString() });
      }
      res.status(500).json({ message: "Failed to create attendance record" });
    }
  });

  // ===== TREASURY ROUTES =====
  app.get("/api/treasury", isAuthenticated, async (req, res) => {
    try {
      const treasuryRecords = await storage.getAllTreasury();
      
      // Members only see their own data, admin sees all
      const filtered = req.user!.role === "admin" 
        ? treasuryRecords 
        : treasuryRecords.filter(t => t.userId === req.user!.id);
      
      // Join with user data
      const treasuryWithUsers = await Promise.all(
        filtered.map(async (record) => {
          const user = await storage.getUser(record.userId);
          return {
            ...record,
            userName: user?.name || "Unknown",
            userEmail: user?.email || "",
          };
        })
      );
      
      res.json(treasuryWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch treasury" });
    }
  });

  app.post("/api/treasury", isAuthenticated, async (req, res) => {
    try {
      const baseSchema = z.object({
        userId: z.string().optional(),
        date: z.string(),
        amount: z.number(),
        type: z.enum(["in", "out"]),
        notes: z.string().optional(),
        proof: z.string().optional(),
        status: z.enum(["pending", "verified"]).optional(),
      });

      const reqData = baseSchema.parse(req.body);
      
      // Different categories for income (in) vs expense (out)
      let data: any = reqData;
      if (reqData.type === "in") {
        const inSchema = z.object({
          category: z.enum(["iuran_wajib", "iuran_sukarela", "denda", "lainnya"]),
        });
        data = { ...reqData, ...inSchema.parse({ category: (req.body as any).category }) };
      } else if (reqData.type === "out") {
        const outSchema = z.object({
          category: z.enum(["konsumsi", "souvenir", "hadiah", "operasional", "lainnya"]),
        });
        data = { ...reqData, ...outSchema.parse({ category: (req.body as any).category }) };
      }
      
      // Members can only create treasury for themselves, admin can create for anyone
      const userId = data.userId || req.user!.id;
      if (req.user!.role !== "admin" && userId !== req.user!.id) {
        return res.status(403).json({ message: "Cannot create treasury for other users" });
      }

      // Members can only create "in" type (payments), not "out"
      if (req.user!.role !== "admin" && data.type === "out") {
        return res.status(403).json({ message: "Members can only create payment records" });
      }

      const treasury = await storage.createTreasury({
        ...data,
        userId,
        status: req.user!.role === "admin" ? (data.status || "verified") : "pending",
      });
      res.status(201).json(treasury);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromError(error).toString() });
      }
      res.status(500).json({ message: "Failed to create treasury record" });
    }
  });

  // Get treasury summary (admin only)
  app.get("/api/treasury/summary", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const all = await storage.getAllTreasury();
      const totalIn = all.filter(t => t.type === "in").reduce((sum, t) => sum + t.amount, 0);
      const totalOut = all.filter(t => t.type === "out").reduce((sum, t) => sum + t.amount, 0);
      const balance = totalIn - totalOut;

      res.json({
        totalBalance: balance,
        totalIncome: totalIn,
        totalExpense: totalOut,
        transactionCount: all.length,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch treasury summary" });
    }
  });

  // Verify treasury payment (admin only)
  app.patch("/api/treasury/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const schema = z.object({
        status: z.enum(["pending", "verified"]).optional(),
        proof: z.string().optional(),
      });

      const data = schema.parse(req.body);
      const updates: any = {};
      if (data.status) updates.status = data.status;
      if (data.proof) updates.proof = data.proof;
      
      const treasury = await storage.updateTreasury(id, updates);
      
      if (!treasury) {
        return res.status(404).json({ message: "Treasury record not found" });
      }

      res.json(treasury);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromError(error).toString() });
      }
      res.status(500).json({ message: "Failed to update treasury record" });
    }
  });

  // Delete treasury record (admin only) 
  app.delete("/api/treasury/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteTreasury(id);
      if (!deleted) {
        return res.status(404).json({ message: "Treasury record not found" });
      }
      res.json({ message: "Treasury record deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete treasury record" });
    }
  });

  // Delete all treasury records (admin only)
  app.delete("/api/treasury-all", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.deleteAllTreasury();
      res.json({ message: "All treasury records deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete treasury records" });
    }
  });

  // Delete attendance record (admin only)
  app.delete("/api/attendance/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteAttendance(id);
      if (!deleted) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      res.json({ message: "Attendance record deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete attendance record" });
    }
  });

  // Delete all attendance records (admin only)
  app.delete("/api/attendance-all", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.deleteAllAttendance();
      res.json({ message: "All attendance records deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete attendance records" });
    }
  });

  // ===== UNPAID MEMBERS ROUTES =====
  app.get("/api/unpaid", isAuthenticated, async (req, res) => {
    try {
      const unpaid = await storage.getAllUnpaidMembers();
      
      // Join with user data
      const unpaidWithUsers = await Promise.all(
        unpaid.map(async (record) => {
          const user = await storage.getUser(record.userId);
          return {
            ...record,
            userName: user?.name || "Unknown",
            userEmail: user?.email || "",
          };
        })
      );
      
      res.json(unpaidWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch unpaid members" });
    }
  });

  app.post("/api/unpaid", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const schema = z.object({
        userId: z.string(),
        month: z.string(),
        amount: z.number(),
      });

      const data = schema.parse(req.body);
      const unpaid = await storage.createUnpaidMember(data);
      res.status(201).json(unpaid);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromError(error).toString() });
      }
      res.status(500).json({ message: "Failed to create unpaid record" });
    }
  });

  app.delete("/api/unpaid/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteUnpaidMember(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Unpaid record not found" });
      }

      res.json({ message: "Unpaid record deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete unpaid record" });
    }
  });

  // ===== NOTIFICATION ROUTES =====
  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.id;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const notifications = await storage.getNotificationsByUserId(userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post("/api/notifications", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const schema = z.object({
        userId: z.string(),
        type: z.string(),
        title: z.string(),
        message: z.string(),
        relatedId: z.string().optional(),
      });

      const data = schema.parse(req.body);
      const notification = await storage.createNotification(data);
      res.status(201).json(notification);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromError(error).toString() });
      }
      res.status(500).json({ message: "Failed to create notification" });
    }
  });

  app.patch("/api/notifications/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const notification = await storage.markNotificationAsRead(id);
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }

      res.json(notification);
    } catch (error) {
      res.status(500).json({ message: "Failed to update notification" });
    }
  });

  return httpServer;
}
