import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, and, desc } from "drizzle-orm";
import * as schema from "@shared/schema";
import type {
  User,
  InsertUser,
  Attendance,
  InsertAttendance,
  Treasury,
  InsertTreasury,
  UnpaidMember,
  InsertUnpaidMember,
  Notification,
  InsertNotification,
} from "@shared/schema";

const sql = neon(process.env.DATABASE_URL!);
const db = drizzle(sql, { schema });

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;

  // Attendance methods
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  getAttendanceByUserId(userId: string): Promise<Attendance[]>;
  getAllAttendance(): Promise<Attendance[]>;
  getAttendanceByDate(date: string): Promise<Attendance[]>;
  deleteAttendance(id: string): Promise<boolean>;
  deleteAllAttendance(): Promise<boolean>;
  updateAttendance(id: string, updates: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  
  // Treasury methods
  createTreasury(treasury: InsertTreasury): Promise<Treasury>;
  getTreasuryByUserId(userId: string): Promise<Treasury[]>;
  getAllTreasury(): Promise<Treasury[]>;
  deleteTreasury(id: string): Promise<boolean>;
  deleteAllTreasury(): Promise<boolean>;
  updateTreasury(id: string, updates: Partial<InsertTreasury>): Promise<Treasury | undefined>;
  
  // Unpaid Members methods
  createUnpaidMember(unpaid: InsertUnpaidMember): Promise<UnpaidMember>;
  getAllUnpaidMembers(): Promise<UnpaidMember[]>;
  deleteUnpaidMember(id: string): Promise<boolean>;

  // Notification methods
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUserId(userId: string): Promise<Notification[]>;
  markNotificationAsRead(id: string): Promise<Notification | undefined>;
}

export class DbStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(schema.users).values(insertUser).returning();
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(schema.users).orderBy(desc(schema.users.createdAt));
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(schema.users).set(updates).where(eq(schema.users.id, id)).returning();
    return result[0];
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await db.delete(schema.users).where(eq(schema.users.id, id)).returning();
    return result.length > 0;
  }

  // Attendance methods
  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const result = await db.insert(schema.attendance).values(insertAttendance).returning();
    return result[0];
  }

  async getAttendanceByUserId(userId: string): Promise<Attendance[]> {
    return await db.select().from(schema.attendance).where(eq(schema.attendance.userId, userId)).orderBy(desc(schema.attendance.date));
  }

  async getAllAttendance(): Promise<Attendance[]> {
    return await db.select().from(schema.attendance).orderBy(desc(schema.attendance.date));
  }

  async getAttendanceByDate(date: string): Promise<Attendance[]> {
    return await db.select().from(schema.attendance).where(eq(schema.attendance.date, date));
  }

  async deleteAttendance(id: string): Promise<boolean> {
    const result = await db.delete(schema.attendance).where(eq(schema.attendance.id, id)).returning();
    return result.length > 0;
  }

  async deleteAllAttendance(): Promise<boolean> {
    await db.delete(schema.attendance);
    return true;
  }

  async updateAttendance(id: string, updates: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const result = await db.update(schema.attendance).set(updates).where(eq(schema.attendance.id, id)).returning();
    return result[0];
  }

  // Treasury methods
  async createTreasury(insertTreasury: InsertTreasury): Promise<Treasury> {
    const result = await db.insert(schema.treasury).values(insertTreasury).returning();
    return result[0];
  }

  async getTreasuryByUserId(userId: string): Promise<Treasury[]> {
    return await db.select().from(schema.treasury).where(eq(schema.treasury.userId, userId)).orderBy(desc(schema.treasury.date));
  }

  async getAllTreasury(): Promise<Treasury[]> {
    return await db.select().from(schema.treasury).orderBy(desc(schema.treasury.date));
  }

  async updateTreasury(id: string, updates: Partial<InsertTreasury>): Promise<Treasury | undefined> {
    const result = await db.update(schema.treasury).set(updates).where(eq(schema.treasury.id, id)).returning();
    return result[0];
  }

  async deleteTreasury(id: string): Promise<boolean> {
    const result = await db.delete(schema.treasury).where(eq(schema.treasury.id, id)).returning();
    return result.length > 0;
  }

  async deleteAllTreasury(): Promise<boolean> {
    await db.delete(schema.treasury);
    return true;
  }

  // Unpaid Members methods
  async createUnpaidMember(insertUnpaid: InsertUnpaidMember): Promise<UnpaidMember> {
    const result = await db.insert(schema.unpaidMembers).values(insertUnpaid).returning();
    return result[0];
  }

  async getAllUnpaidMembers(): Promise<UnpaidMember[]> {
    return await db.select().from(schema.unpaidMembers).orderBy(desc(schema.unpaidMembers.createdAt));
  }

  async deleteUnpaidMember(id: string): Promise<boolean> {
    const result = await db.delete(schema.unpaidMembers).where(eq(schema.unpaidMembers.id, id)).returning();
    return result.length > 0;
  }

  // Notification methods
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const result = await db.insert(schema.notifications).values(insertNotification).returning();
    return result[0];
  }

  async getNotificationsByUserId(userId: string): Promise<Notification[]> {
    return await db.select().from(schema.notifications).where(eq(schema.notifications.userId, userId)).orderBy(desc(schema.notifications.createdAt));
  }

  async markNotificationAsRead(id: string): Promise<Notification | undefined> {
    const result = await db.update(schema.notifications).set({ isRead: 1 }).where(eq(schema.notifications.id, id)).returning();
    return result[0];
  }
}

export const storage = new DbStorage();
